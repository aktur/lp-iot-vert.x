#!/bin/bash

./mvnw clean package
cp target/*-fat.jar ../vms/vm-things/app
cp certificates/*.* ../vms/vm-things/app

