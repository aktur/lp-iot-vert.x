#!/bin/bash
MONGO_PORT="27017" \
MONGO_HOST="things.home.smart" \
MONGO_BASE_NAME="smarthome_db" \
MQTT_KEY="certificates/things.home.smart.key" \
MQTT_CERT="certificates/things.home.smart.crt" \
MQTT_PORT=8883 \
java -jar target/broker-1.0.0-SNAPSHOT-fat.jar


# nc -zv 172.16.114.51 27017
# nc -zv mongo.home.smart 27017
#MQTT_KEY="certificates/mqtt.devsecops.run.key" \
#MQTT_CERT="certificates/mqtt.devsecops.run.crt" \
