#!/bin/bash

multipass --verbose exec broker -- bash << EOF
cd app

#MQTT_KEY="broker.home.smart.key" \
#MQTT_CERT="broker.home.smart.run.crt" \
#MQTT_PORT=8883 \
MONGO_PORT="27017" \
MONGO_HOST="localhost" \
MONGO_BASE_NAME="smarthome_db" \
java -jar broker-1.0.0-SNAPSHOT-fat.jar ;
EOF

#172.16.114.51
#MONGO_HOST="mongo.home.smart" \

# nc -zv 172.16.114.51 27017
# nc -zv mongo.home.smart 27017
