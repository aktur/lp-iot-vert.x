package com.smarthome.broker;

import data.MongoStore;
import handlers.EndPointHandler;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.net.PemKeyCertOptions;
import io.vertx.core.net.PemTrustOptions;
import io.vertx.mqtt.MqttServer;
import io.vertx.mqtt.MqttServerOptions;

import java.util.Optional;

public class MainVerticle extends AbstractVerticle {

  @Override
  public void stop(Promise<Void> stopPromise) throws Exception {
    System.out.println("Broker is stopped");
    stopPromise.complete();
  }

  @Override
  public void start(Promise<Void> startPromise) throws Exception {

    /*
      Define parameters of the application
      ------------------------------------
    */
    // MongoDb parameters
    var mongoPort = Integer.parseInt(Optional.ofNullable(System.getenv("MONGO_PORT")).orElse("27017"));
    var mongoHost = Optional.ofNullable(System.getenv("MONGO_HOST")).orElse("localhost");
    var mongoBaseName = Optional.ofNullable(System.getenv("MONGO_BASE_NAME")).orElse("smarthome_db");

    // Initialize the connection to the MongoDb database
    MongoStore.initialize(vertx, "mongodb://"+mongoHost+":"+mongoPort, mongoBaseName);

    System.out.println("🟩 mongodb://"+mongoHost+":"+mongoPort+ " mongoBaseName: " + mongoBaseName);

    // MQTT parameters
    var mqttPort = Integer.parseInt(Optional.ofNullable(System.getenv("MQTT_PORT")).orElse("1883"));
    var mqttOptions = new MqttServerOptions().setPort(mqttPort);

    /*
      Certificate and Key must be present on the broker side and on the device side
      - To activate SSL with MQTT you need to use setKeyCertOptions and set Ssl to true
      - To activate the "handle check" of the device connection (the broker check if the certificate of the device is correct),
        you need to use setPemTrustOptions method
     */


    var mqttKey = Optional.ofNullable(System.getenv("MQTT_KEY")).orElse("");
    var mqttCert = Optional.ofNullable(System.getenv("MQTT_CERT")).orElse("");
    // Loading certificates only if we set the environment variables MQTT_KEY and MQTT_CERT
    if(!mqttKey.isEmpty() && !mqttCert.isEmpty()) {
      System.out.println("Loading certificates ...");

      mqttOptions
        .setPemTrustOptions(
          new PemTrustOptions().addCertPath(mqttCert)
        )
        .setKeyCertOptions(
          new PemKeyCertOptions()
          .setKeyPath(mqttKey)
          .setCertPath(mqttCert)
        )
        .setSsl(true);
      System.out.println(mqttOptions.getKeyCertOptions().toString());
    }


    // Create the MQTT server
    var mqttServer = MqttServer.create(vertx, mqttOptions);

    /*
      Create handlers for the broker
      ------------------------------------
    */
    mqttServer.endpointHandler(EndPointHandler.handler);

    /*
      Start the MQTT broker
      ------------------------------------
    */
    mqttServer.listen()
      .onFailure(error -> {
        System.out.println("MQTT " + error.getMessage());
      })
      .onSuccess(ok -> {
        System.out.println("MQTT broker started, listening on " + mqttPort);
      });
  }

}
