#!/bin/bash
DEVICE_TYPE="mqtt" \
DEVICE_LOCATION="attic" \
MQTT_CLIENT_ID="121268" \
DEVICE_ID="D_121268" \
MQTT_KEY="certificates/things.home.smart.key" \
MQTT_CERT="certificates/things.home.smart.crt" \
MQTT_PORT=8883 \
MQTT_HOST="localhost" \
MQTT_TOPIC="house" \
java -jar target/smartdevice-1.0.0-SNAPSHOT-fat.jar ;
