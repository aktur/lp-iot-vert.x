# Smartdevice

## Build

To package your application:
```bash
./mvnw clean package
```

To run your application:
```bash
./mvnw clean compile exec:java
```
