#!/bin/bash

./mvnw clean package
cp target/*-fat.jar ../vms/vm-devices/app
cp certificates/*.* ../vms/vm-devices/app
